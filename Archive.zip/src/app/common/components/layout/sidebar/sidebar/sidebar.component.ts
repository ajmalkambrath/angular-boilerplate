import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedService } from 'src/app/common/services/shared.service';

@Component({
  selector: 'app-sidebar',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.scss']
})

export class SidebarComponent {
  isExpanded: boolean = false;

  constructor(private sharedService : SharedService) { }

  /**
   * @methodName toggleSidebarExpand
   * @params none
   * @description used to toggle sidebar
   * @return none
   */
  toggleSidebarExpand(): void {
    this.isExpanded = !this.isExpanded;
    this.sharedService.toggleSidebar$.next(this.isExpanded)
  }
}
