import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HalaMinCardComponent } from './hala-min-card.component';

describe('HalaMinCardComponent', () => {
  let component: HalaMinCardComponent;
  let fixture: ComponentFixture<HalaMinCardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ HalaMinCardComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(HalaMinCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
