import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MINI_CARD_DATA } from '../../test-data';
import { MiniCard } from '../../models/mini-card.model';

@Component({
  selector: 'app-hala-min-card',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './hala-min-card.component.html',
  styleUrls: ['./hala-min-card.component.scss']
})

export class HalaMinCardComponent {
@Input() data: MiniCard[] = MINI_CARD_DATA;

  ngOnInit(): void {
    if(this.data) {
      this.data.map( item => {
        item['color'] = this.getColorByStatus(item.status);
      });
    }
  }

  getColorByStatus(status: string): string {
    switch (status) {
      case 'status1':
        return '#8B5CF6';
      case 'status2':
        return '#3B82F6';
      case 'status3':
        return '#14B8A6';
      case 'status4':
        return '#F97316';
      case 'status5':
        return '#84CC16';
      case 'status6':
        return '#EC4899';
      default:
        return '#8B5CF6';
    }
  }
}
