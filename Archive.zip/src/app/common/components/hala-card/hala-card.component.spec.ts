import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HalaCardComponent } from './hala-card.component';

describe('HalaCardComponent', () => {
  let component: HalaCardComponent;
  let fixture: ComponentFixture<HalaCardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ HalaCardComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(HalaCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
