import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-hala-card',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './hala-card.component.html',
  styleUrls: ['./hala-card.component.scss']
})
export class HalaCardComponent {
  @Input() showAllCards = false;
  @Input() data: any;

}
