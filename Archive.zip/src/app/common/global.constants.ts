export const TRANSLATION_DATA = {
    LANGUAGES: [
        {
            LANGUAGE_ISO_CODE: 'en',
            LANGUAGE_TEXT: 'Eng'
        },
        {
            LANGUAGE_ISO_CODE: 'ar',
            LANGUAGE_TEXT: 'عربى'
        }
    ],
    DEFAULT_LANGUAGE: 'en'
};
export const LANGUAGES_AVAILABLE = TRANSLATION_DATA.LANGUAGES.map(LANG => LANG.LANGUAGE_ISO_CODE);