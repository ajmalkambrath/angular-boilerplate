export const MINI_CARD_DATA = [
    { name:'Tammam Altammam', department: 'Marketing Department', amount: '16,003.00', currency: 'SAR', status: 'status1', date: '12 / 23' },
    { name:'Tammam Altammam', department: 'Marketing Department', amount: '16,003.00', currency: 'SAR', status: 'status2', date: '12 / 23'},
    { name:'Tammam Altammam', department: 'Marketing Department', amount: '16,003.00', currency: 'SAR', status: 'status3', date: '12 / 23' },
    { name:'Tammam Altammam', department: 'Marketing Department', amount: '16,003.00', currency: 'SAR', status: 'status4', date: '12 / 23' },
    { name:'Tammam Altammam', department: 'Marketing Department', amount: '16,003.00', currency: 'SAR', status: 'status5', date: '12 / 23' },
    { name:'Tammam Altammam', department: 'Marketing Department', amount: '16,003.00', currency: 'SAR', status: 'status6', date: '12 / 23' },
  ];

  export const CHART_DATA = [
    { name:'Groceries', value: '1500.00 SAR', txn: '13 Transactions', percent: '56%', color:'#009877'},
    { name:'Restaurants & Cafes', value: '1500.00 SAR', txn: '13 Transactions', percent: '6%', color:'#22C55E'},
    { name:'Auto & Transport', value: '1500.00 SAR', txn: '13 Transactions', percent: '26%', color:'#009877'},
    { name:'Travel', value: '1500.00 SAR', txn: '13 Transactions', percent: '36%', color:'#8B5CF6'},
    { name:'Travel', value: '1500.00 SAR', txn: '13 Transactions', percent: '46%', color:'#A5B4FC'},
  ];

  export const NAVBAR_LIST = [
    { navIcon: 'la-tachometer-alt', navText: 'tr_menu_dashboard', navLink: 'dashboard'},
    { navIcon: 'la-credit-card', navText: 'tr_menu_card_management', navLink: 'dashboard'},
    { navIcon: 'la-download', navText: 'tr_menu_requests', navLink: 'dashboard'},
    { navIcon: 'la-exchange-alt', navText: 'tr_menu_transactions', navLink: 'dashboard'},
    { navIcon: 'la-headphones', navText: 'tr_menu_help_support', navLink: 'dashboard'},
    { navIcon: 'la-file-alt', navText: 'tr_menu_privacy_policy', navLink: 'dashboard'},
    { navIcon: 'la-file-invoice', navText: 'tr_menu_terms_conditions', navLink: 'dashboard'},
    { navIcon: 'la-question-circle', navText: 'tr_menu_faqs', navLink: 'dashboard'},
    { navIcon: 'la-cog', navText: 'tr_menu_settings', navLink: 'dashboard'},
    { navIcon: '/assets/icons/account.svg', navText: 'tr_menu_logout', navLink: 'dashboard'},
];

export const HALA_CARD_DATA = { title:'Available Balance', amount: '16,003.00', currency: 'SAR', transferAmount: ['Transfer amount'], card:'SA83 9000 0000 0299 0047 4640'};

export const HALA_ALL_CARD_DATA = { title:'Cards Balance', amount: '16,003.00', currency: 'SAR', transferAmount: ['Issue New Card', 'Fund Card']};
