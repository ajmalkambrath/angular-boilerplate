export class MiniCard  { 
  name: string;
  department: string;
  amount: string;
  currency: string;
  status: string;
  date: string;
  color?: string;
}