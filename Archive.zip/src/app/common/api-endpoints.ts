export const CARD_STATUS_API_URL = '/cards/';
