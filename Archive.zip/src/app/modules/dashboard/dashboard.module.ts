import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DashboardRoutingModule } from './dashboard-routing.module';
import { DashboardComponent } from './components/dashboard.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HalaCardComponent } from 'src/app/common/components/hala-card/hala-card.component';
import { HalaMinCardComponent } from 'src/app/common/components/hala-min-card/hala-min-card.component';
import { TranslateModule } from '@ngx-translate/core';


@NgModule({
  declarations: [
    DashboardComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    DashboardRoutingModule,
    HalaCardComponent,
    HalaMinCardComponent,
    TranslateModule.forChild({ isolate: false }),
  ]
})
export class AuthModule { }
