import { Injectable } from '@angular/core';
import { CARD_STATUS_API_URL } from 'src/app/common/api-endpoints';
import { ApiService } from 'src/app/common/services/api.service';

@Injectable({
  providedIn: 'root'
})

export class DashboardService {

  constructor( private http: ApiService) {
  }

  getCardData() {
    const URL = CARD_STATUS_API_URL;
    return this.http.get(URL);
  }
}