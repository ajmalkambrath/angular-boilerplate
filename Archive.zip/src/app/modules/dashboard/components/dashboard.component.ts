import { ChangeDetectionStrategy, ChangeDetectorRef, Component, OnDestroy, OnInit } from '@angular/core';
import { Chart, registerables } from 'chart.js';
import { Subscription } from 'rxjs';
import { CHART_DATA, HALA_ALL_CARD_DATA, HALA_CARD_DATA } from 'src/app/common/test-data';
import { DashboardService } from '../services/dashboard.service';
Chart.register(...registerables);

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class DashboardComponent implements OnInit, OnDestroy {
  CHART_DATA = CHART_DATA;
  HALA_CARD_DATA = HALA_CARD_DATA;
  HALA_ALL_CARD_DATA = HALA_ALL_CARD_DATA;
  sidebarToggle = false;
  subscription$ = new Subscription();
  constructor(
    private dashBoardService: DashboardService,
    public changeDetectRef:ChangeDetectorRef
    ) { }

  ngOnInit() {
    this.handleChart();
    this.loadCardData();
  }

  /**
   * @methodName loadCardData
   * @description used to load card data
   * @parameters none
   * @return none
   */
  loadCardData() {
   this.subscription$.add(this.dashBoardService.getCardData().subscribe( response => {
      console.log(response);
    }));
  }

  /**
   * @methodName handleChart
   * @description used to handle chart
   * @parameters none
   * @return none
   */
  handleChart(): void {

    new Chart("myChart", {
      type: 'doughnut',
      data: {
        datasets: [{
          data: [10, 20, 51, 20, 5],
          backgroundColor: [
            '#22C55E',
            '#009877',
            '#8B5CF6',
            '#A5B4FC',
            '#009877',
          ],
          borderWidth: 2
        }]
      },
      options: {
      }
    });
  }

  ngOnDestroy() {
    if (this.subscription$) { this.subscription$.unsubscribe(); }
  }
}
